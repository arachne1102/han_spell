package com.example.spelling_check_application

import android.content.Intent
import android.os.Bundle
import android.os.Environment
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.spelling_check_application.databinding.ActivityMainBinding
import com.example.spelling_check_application.network.NetworkService
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.FileInputStream
import java.io.FileOutputStream

private lateinit var binding: ActivityMainBinding

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        var btnSend = findViewById<Button>(R.id.btn_send) //보내기 버튼
        var btnSave = findViewById<Button>(R.id.btn_save) //세이브 버튼
        var btnCheck = findViewById<Button>(R.id.btn_check) // 검사하기 버튼
        val btnApply = findViewById<Button>(R.id.btn_apply)
        var InformationLayout = findViewById<LinearLayout>(R.id.InformationLie_Layout)
        var imm : InputMethodManager? = null

        var textSave : String? = null

        textCounter()
        setBottomNavigation()


        imm = getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as InputMethodManager?

        btnSend.setOnClickListener(){ //보내기 버튼 작동 함수
            textSend() //함수
        }

        btnSave.setOnClickListener(){
            output()
        }

        btnCheck.setOnClickListener {
            val inputText = binding.editTextTextWrite.text.toString().trim()

            if (inputText.isNotEmpty()) {
                val networkService = NetworkService()
                networkService.sendTextToServer(inputText) { response ->
                    runOnUiThread {
                        if (response != null) {
                            // 서버 응답 성공 시 데이터 처리
                            val originalText = response.original_text
                            val correctedText = response.corrected_text
                            val spellingCorrections = response.spelling_errors

                            // 결과를 Toast로 출력
                            Toast.makeText(
                                this,
                                "원본: $originalText\n수정된 텍스트: $correctedText\n교정: $spellingCorrections",
                                Toast.LENGTH_LONG
                            ).show()

                            textCheck("수정된 텍스트\n-------------\n\n $correctedText\n\n\n교정\n-------------\n\n $spellingCorrections")
                            textSave = correctedText

                            textApplyVisibility()
                        } else {
                            // 서버 응답 실패 시 처리
                            Toast.makeText(this, "서버 요청 실패", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            } else {
                // 텍스트가 비어 있으면 경고 메시지 표시
                Toast.makeText(this, "텍스트를 입력하세요.", Toast.LENGTH_SHORT).show()
            }
        }

        btnApply.setOnClickListener(){
            if (textApplyControl(textSave)){
                textApplyVisibilityReturn()
                textSave = null
                textCheckReturn()
                Toast.makeText(this, "적용에 성공했습니다.", Toast.LENGTH_SHORT).show()
            }
        }

    }

    private fun textCounter(){ //글자수 세는 함수
        val editText = findViewById<TextView>(R.id.editText_text_Write) //글 쓰는 곳
        var textCount = findViewById<TextView>(R.id.letterCount_textview) //글자수
        var editTextbodyText = findViewById<TextView>(R.id.editText_bodyText)
        var bodytextCount = findViewById<TextView>(R.id.bodyText_letterCount_textview)

        editText.addTextChangedListener(object : TextWatcher { //글자수 세기
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                var input = editText.text.toString()
                textCount.setText("글자수 : "+input.length) //실시간 글자수 세기
            }

            override fun afterTextChanged(p0: Editable?) {

            }
        })



        editTextbodyText.addTextChangedListener(object : TextWatcher { //본문 글자수 세기
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                var input2 = editTextbodyText.text.toString()
                bodytextCount.setText("글자수 : "+input2.length)
            }

            override fun afterTextChanged(p0: Editable?) {

            }
        })
    }

    private fun setBottomNavigation(){ //하단 네비게이션 뷰 제어
        binding.BottomNavigationView.selectedItemId = R.id.navigation_write //첫 화면 작성으로 고정

        binding.BottomNavigationView.setOnItemSelectedListener {
            when (it.itemId){ //현재 아이템 확인
                R.id.navigation_write -> onClickWrite() //현재 화면 확인
                R.id.navigation_bodytext -> onClickBodytext()
                else -> onClickSavelist()
            }
        }
    }

    private fun onClickWrite(): Boolean { //작성 ui 제어
        var writeLayout = findViewById<LinearLayout>(R.id.Write_Layout)
        var bodytextLayout = findViewById<LinearLayout>(R.id.bodyText_Layout)

        writeLayout.visibility = View.VISIBLE
        bodytextLayout.visibility = View.INVISIBLE

        var btnSend = findViewById<Button>(R.id.btn_send)
        var btnSvae = findViewById<Button>(R.id.btn_save)
        var btnCheck = findViewById<Button>(R.id.btn_check)

        btnSend.visibility = View.VISIBLE
        btnSvae.visibility = View.INVISIBLE
        btnCheck.visibility = View.VISIBLE


        return true
    }

    private fun onClickBodytext(): Boolean { //본문 ui 제어
        var writeLayout = findViewById<LinearLayout>(R.id.Write_Layout)
        var bodytextLayout = findViewById<LinearLayout>(R.id.bodyText_Layout)

        writeLayout.visibility = View.INVISIBLE
        bodytextLayout.visibility = View.VISIBLE

        var btnSend = findViewById<Button>(R.id.btn_send)
        var btnSvae = findViewById<Button>(R.id.btn_save)
        var btnCheck = findViewById<Button>(R.id.btn_check)

        btnSend.visibility = View.INVISIBLE
        btnSvae.visibility = View.VISIBLE
        btnCheck.visibility = View.GONE

        return true
    }

    private fun onClickSavelist(): Boolean {
        val intent = Intent(this, TextListSaveActivity::class.java)
        startActivity(intent)

        return true
    }



    private fun textSend(){ //텍스트 보내기
        var editText = findViewById<TextView>(R.id.editText_text_Write) //에딧 텍스트가 작성 화면
        var editTextbodyText = findViewById<TextView>(R.id.editText_bodyText)//에딕 바디 텍스트가 본문 화면

        if(editText.text.toString().length != 0){
            Toast.makeText(this@MainActivity, "작성하신 글을 본문으로 보냈습니다.", Toast.LENGTH_SHORT).show()

            editTextbodyText.text = editTextbodyText.text.toString() + editText.text.toString() + "\n\n"
            editText.text = ""

            Log.d( "bodyText",editTextbodyText.text.toString())
        }
    }

    private fun textCheck(textchecker :String){
        var textCheck = findViewById<TextView>(R.id.textcheck)

        textCheck.visibility = View.VISIBLE

        textCheck.text = textchecker
    }

    private fun textCheckReturn(){
        var textCheck = findViewById<TextView>(R.id.textcheck)

        textCheck.visibility = View.GONE
    }

    private fun textApplyVisibility(){
        val btn_apply = findViewById<Button>(R.id.btn_apply)
        val btn_check = findViewById<Button>(R.id.btn_check)

        btn_apply.visibility = View.VISIBLE
        btn_check.visibility = View.GONE
    }

    private fun textApplyVisibilityReturn(){
        val btn_apply = findViewById<Button>(R.id.btn_apply)
        val btn_check = findViewById<Button>(R.id.btn_check)

        btn_apply.visibility = View.GONE
        btn_check.visibility = View.VISIBLE
    }

    private fun textApplyControl(textSave :String?): Boolean {
        val editTextTextWrite = findViewById<TextView>(R.id.editText_text_Write)

        if (textSave != null) {
            editTextTextWrite.text = textSave.toString()
            return true
        }
        else{
            return false
        }




    }

    var path :String? = null

    private fun output(){
        path = Environment.getExternalStorageDirectory().absolutePath + "/Spelling_Check_Application"
        var text = findViewById<TextView>(R.id.editText_bodyText)
        var output = FileOutputStream(path)
        var dos = DataOutputStream(output)

        dos.writeUTF(text.toString())
        dos.flush()
        dos.close()
    }

    private fun input(textname :String){
        path = Environment.getExternalStorageDirectory().absolutePath + "/Spelling_Check_Application" + textname
        var input = FileInputStream(path)
        var dis = DataInputStream(input)

        var valueUTF = dis.readUTF()
        dis.close()

    }
}