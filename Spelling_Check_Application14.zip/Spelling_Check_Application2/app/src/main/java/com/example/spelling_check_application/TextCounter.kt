package com.example.spelling_check_application

import android.text.Editable
import android.text.TextWatcher
import android.widget.TextView

class TextCounter {

    var customDialog = MainActivity()

    val mainActivity = MainActivity()

    fun textCounter(){ //글자수 세는 함수
        val editText = mainActivity.findViewById<TextView>(R.id.editText_text_Write) //글 쓰는 곳
        var textCount = mainActivity.findViewById<TextView>(R.id.letterCount_textview) //글자수
        var editTextbodyText = mainActivity.findViewById<TextView>(R.id.editText_bodyText)
        var bodytextCount = mainActivity.findViewById<TextView>(R.id.bodyText_letterCount_textview)

        editText.addTextChangedListener(object : TextWatcher { //글자수 세기
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                var input = editText.text.toString()
                textCount.setText("글자수 : "+input.length) //실시간 글자수 세기
            }

            override fun afterTextChanged(p0: Editable?) {

            }
        })



        editTextbodyText.addTextChangedListener(object : TextWatcher { //본문 글자수 세기
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                var input2 = editTextbodyText.text.toString()
                bodytextCount.setText("글자수 : "+input2.length)
            }

            override fun afterTextChanged(p0: Editable?) {

            }
        })
    }
}