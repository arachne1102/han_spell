package com.example.spelling_check_application

import android.app.Dialog
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.setMargins

class TextListSaveActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_text_list_save)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val btn_Test = findViewById<Button>(R.id.btn_test)
        btn_Test.setOnClickListener(){
            addSave()
        }
    }

    private fun addSave(){
        val saveText = TextView(this)
        saveText.text = onAlertDialog()

        val save_Scroll_Layout = findViewById<LinearLayout>(R.id.save_scroll_layout)
        val saveCardView = CardView(this)
        val layoutParamsbasic = RelativeLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        layoutParamsbasic.setMargins(15, 15, 15, 50)



        saveCardView.layoutParams = layoutParamsbasic
        saveCardView.radius = 12F
        saveCardView.setContentPadding(25, 25, 25, 25)
        saveCardView.cardElevation = 8F
        saveCardView.maxCardElevation = 12F



        saveText.textSize = 24f

        val cardLinearLayout = LinearLayout(this)
        cardLinearLayout.orientation = LinearLayout.VERTICAL
        cardLinearLayout.gravity = Gravity.CENTER

        if(saveText.length() != 0){
            cardLinearLayout.addView(saveText)
            saveCardView.addView(cardLinearLayout)
            save_Scroll_Layout.addView(saveCardView)
        }






    }

    private fun onAlertDialog() : String? {
        val dialog = AlertDialog.Builder(this)

        dialog.setTitle("제목을 작성해주세요.")

        val et : EditText = EditText(this)
        et.text = null
        dialog.setView(et)


        dialog.setPositiveButton("확인"){
            dialog, _->
            if(et.length() != 0){
                Toast.makeText(this, "새로운 텍스트 파일 생성", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
            else
                Toast.makeText(this, "제목을 지어주세요.", Toast.LENGTH_SHORT).show()
        }
        dialog.setNeutralButton("취소"){
                dialog, _->
                Toast.makeText(this, "취소 합니다.", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
        }
        dialog.show()


        return et.text.toString()
    }

}