package com.example.spelling_check_application

import com.example.spelling_check_application.databinding.ActivityMainBinding

class BottomNavigationControler {
    private lateinit var binding: ActivityMainBinding



}