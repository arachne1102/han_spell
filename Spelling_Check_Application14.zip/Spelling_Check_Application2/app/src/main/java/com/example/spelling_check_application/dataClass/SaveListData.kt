package com.example.spelling_check_application.dataClass

data class SaveListData (
    val name : String
)